<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central place for reading plugin options with sane defaults, so every class
 * reads them the same way.
 */
class LPICS_Options {

	public static function get( $key, $default = '' ) {
		return get_option( 'lpics_' . $key, $default );
	}

	public static function set( $key, $value ) {
		return update_option( 'lpics_' . $key, $value );
	}

	public static function delete( $key ) {
		return delete_option( 'lpics_' . $key );
	}

	/** Connected once we have credentials plus a chosen target calendar URL. */
	public static function is_connected() {
		return (bool) self::get( 'apple_id', '' )
			&& (bool) self::get( 'app_password', '' )
			&& (bool) self::get( 'calendar_url', '' );
	}

	public static function sync_out_enabled() {
		return self::get( 'sync_out', '1' ) === '1';
	}

	public static function block_busy_enabled() {
		// 1.4.2: off by default, and switched off once on existing installs, because
		// a booking's own iCloud event made its slot unavailable to everyone else.
		if ( '1' !== self::get( 'block_busy_reset_142', '' ) ) {
			self::set( 'block_busy', '0' );
			self::set( 'block_busy_reset_142', '1' );
		}
		return self::get( 'block_busy', '0' ) === '1';
	}

	/** Attach a "new booking" alarm to freshly-created events so the owner is alerted. */
	public static function notify_on_create_enabled() {
		return self::get( 'notify_on_create', '1' ) === '1';
	}

	/** Absolute CalDAV URL of the chosen calendar collection. */
	public static function calendar_url() {
		return trim( (string) self::get( 'calendar_url', '' ) );
	}

	/** Which LatePoint agent this connected iCloud account represents. 0 = all/any. */
	public static function agent_id() {
		return (int) self::get( 'agent_id', 0 );
	}

	/** Max people per slot (LatePoint service capacity_max). 0 = off, leave services alone. */
	public static function slot_capacity() {
		return max( 0, (int) self::get( 'slot_capacity', 0 ) );
	}

	/**
	 * Write the chosen capacity into every LatePoint service. LatePoint core already
	 * enforces services.capacity_max when it checks a slot (OsBookingHelper::
	 * is_timeframe_in_booked_periods), but the free plugin has no field to edit it.
	 * Turning the option off resets services we changed back to 1.
	 */
	public static function apply_slot_capacity() {
		global $wpdb;
		if ( ! defined( 'LATEPOINT_TABLE_SERVICES' ) ) {
			return;
		}
		$cap     = self::slot_capacity();
		$applied = (int) self::get( 'slot_capacity_applied', 0 );
		if ( $cap >= 2 ) {
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . LATEPOINT_TABLE_SERVICES . ' SET capacity_min = 1, capacity_max = %d', $cap ) );
			self::set( 'slot_capacity_applied', $cap );
		} elseif ( $applied >= 2 ) {
			$wpdb->query( 'UPDATE ' . LATEPOINT_TABLE_SERVICES . ' SET capacity_min = 1, capacity_max = 1' );
			self::set( 'slot_capacity_applied', 0 );
		}
	}
}
